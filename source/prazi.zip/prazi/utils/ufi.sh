# run from repo base directory
export CARGOGRAPH_DIR=/data/all/downloaded/packages
export UFI_DIR=/data/to/store/prazi/artifacts
mkdir -p $UFI_DIR
cd $CARGOGRAPH_DIR
export LD_LIBRARY_PATH=$(rustc --print sysroot)/lib:$LD_LIBRARY_PATH
ls -d */* | parallel 'if [ -f {}/callgraph.dot ];
			then rm {}/callgraph.unmangled.graph;
                        rustfilt -i {}/callgraph.dot -o {}/callgraph.unmangled.graph; 
                        python src/prune_cg.py $CARGOGRAPH_DIR/{} callgraph.unmangled.graph;
                        target/release/ufi $CARGOGRAPH_DIR/{};
                        python utils/prepare_unified_callgraphs.py $CARGOGRAPH_DIR/{}/callgraph.ufi.graph > $CARGOGRAPH_DIR/{}/callgraph.ufi.prepared.graph; fi' 
rm $UFI_DIR/callgraph.ufi.notmerged.graph
find . -name "callgraph.ufi.prepared.graph" -print0 | parallel -j1 -0 "cat {} >> $UFI_DIR/callgraph.ufi.notmerged.graph"
python utils/merge_unified_callgraphs.py $UFI_DIR/callgraph.ufi.notmerged.graph 1> $UFI_DIR/callgraph.ufi.merged.graph 2> $UFI_DIR/callgraph.ufi.merged.graph.log
python utils/infer_dependency_network_from_callgraphs.py $UFI_DIR/callgraph.ufi.merged.graph 1> $UFI_DIR/crate.dependency.callgraph.graph 2> $UFI_DIR/crate.dependency.callgraph.graph.log
