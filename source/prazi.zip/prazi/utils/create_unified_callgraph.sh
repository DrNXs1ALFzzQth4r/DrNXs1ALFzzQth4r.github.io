#!/bin/bash

# Go to the place where all the crates live
cd /data/all/packages
ls -d */* | parallel cat {}/callgraph.ufi.prepared.dot '>>' /data/ufi.almostdot
cat /data/ufi.almostdot | sort | uniq | grep -w -v "digraph {" | grep -w -v "}" > /data/ufi.almostdot
echo "digraph {" > ufi.dot
cat /data/ufi.almostdot >> /data/ufi.dot
echo "}" >> /data/ufi.dot
# rm /data/ufi.almostdot

