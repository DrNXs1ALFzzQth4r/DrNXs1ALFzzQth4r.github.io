#!/usr/bin/env python

# Analyze the log output of the ecosystem build process.
#
# (c) 2018 - onwards ANON

import sys
import re
import pprint
from operator import itemgetter

rustc_misc_errors = []
rustc_misc = {}
rustc = {}
deps = {}
errors =  {}
builds = 0
calls_to_analyze = 0
crates_with_failures = set()

def add_dict(dictionary, key):
    if key in dictionary.keys():
        dictionary[key] += 1
    else:
        dictionary[key] = 1


def add_missing_dep(dep):
    add_dict(deps, dep)


def add_error(error):
    add_dict(errors, error)


def add_rust_misc_error(error):
    rustc_misc_errors.append(error)
    add_dict(rustc_misc, error)


def add_rust_error(error):
    add_dict(rustc, error)


def print_dict_sorted(dictionary):
    for k,v in sorted(dictionary.items(), key=itemgetter(1), reverse=True):
        print('{}: {}'.format(k,v))


def analyze_build_failure(library, log):
    global calls_to_analyze
    if len(log.rstrip()) == 0:
        return

    crates_with_failures.add(library.split(",")[1])

    calls_to_analyze += 1
    # Don't bother with multiline regexps
    log_default = log
    log = log.replace("\n"," ")

    if re.match(".*no library targets found.*", log):
        add_error('Crate is not a library')
    elif re.match(".* unable to get packages from source.*", log):
        add_error('No package at source')
    elif re.match(".*failed to run custom build command.*", log):
        m = re.match(".*Package (.*) was not found .*", log)
        if m:
            add_missing_dep(m.group(1))
            add_error('Missing system dependency')
        else:
            add_error('Custom build script failed')
    elif re.match(".*error(\[E[0-9]+\])?: .*", log):
        m = re.match(".*error\[(E[0-9]+)\]: .*", log)
        if m:
            add_rust_error(m.group(1))
            add_error("Rustc error with error code")
            return

        error = filter(lambda x: x.startswith("error: "), log_default.split("\n"))

        if len(error) > 0:
            add_rust_misc_error(" ".join(error[0].split(' ')[1:5]))
            add_error("Misc RustC error")
    else:
        add_error('unresolved')


crates_with_success = set()
success_builds = 0

def analyze_build_sucess(line):
    global success_builds
    # Mar 02 13:30:24.057 INFO (none,dft,0.3.0,stdout): crate already have a bitcode file
    fragments = line.split(',')
    if len(fragments) > 2:
        crates_with_success.add(fragments[1])

    if re.match(".*crate already have a bitcode.*", line):
        success_builds += 1

with open(sys.argv[1]) as f:
    parsing = False
    log = ''
    library = ''
    for line in f:
        m = re.match('.* (ERRO|INFO) ([^:]+):\w*', line)
        if m:
            builds += 1
            print "\rBuilds analyzed: %d" % builds,

            if m.group(1) == 'INFO':
                analyze_build_sucess(line)
                parsing = False
                analyze_build_failure(library, log)
                log = ''
                continue

            analyze_build_failure(library, log)
            parsing = True
            library = m.group(2)
            log = ":".join(line.split(':')[3:])
        else:
            if parsing:
                log += line


pp = pprint.PrettyPrinter(indent=2)
print
print "Successful builds: %d" % success_builds
print "Crates with at least one succesful build: %d" % len(crates_with_success)
print "Total crates built: %d" % len(crates_with_success.union(crates_with_failures))
print "Build errors found: %d" % calls_to_analyze
print "====errors======================="
print_dict_sorted(errors)
print "====rustc error codes============"
print_dict_sorted(rustc)
print "====missing deps================="
print_dict_sorted(deps)
#print "====misc rustc errors============"
#print_dict_sorted(rustc_misc)

error_class = {}
print "====misc rustc errors (classified)"

for key in rustc_misc_errors:

    if key.startswith("environment variable"):
        add_dict(error_class, "missing environment variable")
    elif re.match(".*Package .* does", key):
        add_dict(error_class, "package .* does not have these features")
    elif re.match(".*type `.*` is .*", key):
        add_dict(error_class, "type .* is .*")
    elif key.startswith("expected identifier, found"):
        add_dict(error_class, "expected identifier, found .*")
    elif key.startswith("no rules expected"):
        add_dict(error_class, "no rules expected the token .*")
    elif key.startswith("expected one of"):
        add_dict(error_class, "expected one of .* found .*")
    elif key.startswith("no matching version"):
        add_dict(error_class, "no matching version .* found for package")
    elif key.startswith("cyclic package"):
        add_dict(error_class, "cyclic package dependency")
    elif key.startswith("format argument must be"):
        add_dict(error_class, "format argument must be a string literal")
    else:
        add_dict(error_class, "I don't know!")

print_dict_sorted(error_class)
