use std::env;
use std::path::PathBuf;

lazy_static! {
    pub static ref WORK_DIR: PathBuf = {
        env::var_os("CRATERGRAPH")
            .unwrap_or_else(|| env::home_dir().expect("Home directory Missing").join("cratergraph").into_os_string())
            .into()
    };
    
    //Repository dir
    pub static ref REPO_DIR: PathBuf = WORK_DIR.join("repo");

    //Experiment data
    pub static ref EX_DIR: PathBuf = WORK_DIR.join("experiment");
    //Logs
    pub static ref LOG_DIR: PathBuf = WORK_DIR.join("logs");

    // Lists of crates
    pub static ref LIST_DIR: PathBuf = WORK_DIR.join("shared/lists");

    // Where crates.io sources are stores
    pub static ref CRATES_DIR: PathBuf = WORK_DIR.join("shared/crates");
}
