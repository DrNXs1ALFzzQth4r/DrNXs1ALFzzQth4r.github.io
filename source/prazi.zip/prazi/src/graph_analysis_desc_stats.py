# graph_analysis.py
#
# (c) 2017 - onwards ANON
#
# MIT licensed -- check LICENSE file in top dir
import networkx as nx

import json
import sys
import re
from networkx.algorithms.approximation import kcomponents
from networkx.algorithms.approximation import connectivity
from networkx.algorithms.connectivity import connectivity
import operator

regex = r"^(.*?) \[label:"


def read_dep_graph(base_dir):
    nodes = json.load(open(base_dir + '/nodes.json'))
    edges = json.load(open(base_dir + '/edges.json'))

    DEPG = nx.DiGraph()

    for node in nodes['nodes']:
        DEPG.add_node(node)

    for edge in edges['versions']:
        DEPG.add_edge(edge[0]['id'], edge[1]['id'])

    return DEPG


def read_ucg(base_dir):
    UCG = nx.DiGraph()
    with open(base_dir) as f:
        for line in f:
            if "->" not in line:
                g = re.match(regex, line)
                if g:
                    UCG.add_node(g.group(1).strip('"'))
                else:
                    print "error, could not extract node: %s" % line
            else:
                g = re.match('\W*"(.*)" -> "(.*)";', line)
                if g:
                    UCG.add_edge(g.group(1), g.group(2))
                else:
                    print "error, could not extract edge: %s" % line
    return UCG


def create_graph(seed_fn):
    dataset = []
    search_list = set()
    visited = []
    result = list(UCG.predecessors(seed_fn))
    for r in result:
        search_list.add(r)
        dataset.append((seed_fn, r))
    
    while search_list:
        print search_list
        search_value = search_list.pop()
        visited.append(search_value)

        result = list(UCG.predecessors(search_value))
        for r in result:
            if r not in visited:
                search_list.add(r)
            dataset.append((search_value, r))

    return dataset



print "Starting"
UCG = read_ucg(sys.argv[1])
print "Read in graph"
undirected_UCG = UCG.to_undirected()
print "Converted graph to undirected"

# number of recursive functions:
print "Number of recursive functions: ", UCG.number_of_selfloops()

print "Node connectivity: ", nx.algorithms.approximation.connectivity.node_connectivity(UCG)

print "Clustering coefficient: ", nx.algorithms.approximation.clustering_coefficient.average_clustering(undirected_UCG, 100000)

print "Computing page rank ..."
pr = nx.pagerank(UCG)
sorted_pr = sorted(pr.items(), key=operator.itemgetter(1), reverse=True)
for i in range(10):
    print sorted_pr[i], "in-degree:", UCG.in_degree(sorted_pr[i][0])

print "Computing node centrality ..."
pr = nx.degree_centrality(UCG)
sorted_pr = sorted(pr.items(), key=operator.itemgetter(1), reverse=True)
for i in range(10):
    print sorted_pr[i], "in-degree:", UCG.in_degree(sorted_pr[i][0])



no_cycles_UCG = UCG.copy()
# create undirected graph
selfloops = no_cycles_UCG.selfloop_edges()
no_cycles_UCG.remove_edges_from(selfloops)
has_cycles = not nx.algorithms.dag.is_directed_acyclic_graph(no_cycles_UCG)
print "Has cycles? ", has_cycles

removed_cycles = 0
while has_cycles:
    try:
        cycle = nx.algorithms.cycles.find_cycle(no_cycles_UCG)
        no_cycles_UCG.remove_edges_from(cycle)
        removed_cycles += 1
    except:
        has_cycles = False

nx.write_edgelist(no_cycles_UCG, sys.argv[1] + ".dag.gz")

longest_path = nx.algorithms.dag.dag_longest_path(no_cycles_UCG)
print "Longest path length (nodes): ", len(longest_path)
print "Longest path: ", longest_path

# can't really interpret this
print "Number of approximate k-components: ", nx.algorithms.approximation.kcomponents.k_components(no_cycles_UCG.to_undirected()).__len__()

# takes forever
print "Average node connectivity: ", nx.algorithms.connectivity.connectivity.average_node_connectivity(UCG)