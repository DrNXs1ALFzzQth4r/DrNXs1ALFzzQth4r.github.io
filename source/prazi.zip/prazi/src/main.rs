#[macro_use(slog_info, slog_log, slog_error, slog_record,
            slog_record_static, slog_b, slog_kv)]
extern crate slog;
#[macro_use]
extern crate slog_scope;
extern crate slog_term;

extern crate git2;

extern crate cratergraph;
use cratergraph::core::crates::{prepare, islibrary, readable_manifest, build_crate, check_crate, is_library_name, readable_crates_manifest, build_callgraph};
use cratergraph::log;



fn main() {
    let _guard = log::init();


    // match prepare() {
    //     Ok(_) => info!("Done!"),
    //     Err(e) => error!("We failed with the error {}!", e),
    // }
    // match readable_manifest() {
    //     Ok(_) => info!("Done!"),
    //     Err(e) => error!("We failed with the error {}!", e),
    // }

    // match islibrary() {
    //     Ok(_) => info!("Done!"),
    //     Err(e) => error!("We failed with the error {}!", e),
    // }
    match build_callgraph() {
        Ok(_) => info!("Done!"),
        Err(e) => error!("We failed with the error {}!", e),
    }
    log::finish();
}