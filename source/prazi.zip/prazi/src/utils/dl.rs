//based on https://github.com/rust-lang-nursery/crater/blob/28c2e3c74520b9beeab5af781cc5f6cc75815437/src/dl.rs
use std::thread;
use std::time::Duration;
use errors::*;
use std::fs;
use std::path::Path;
use reqwest;

pub fn try_hard<F, R>(f: F) -> Result<R>
where
    F: Fn() -> Result<R>,
{
    try_hard_limit(1000, f)
}

pub fn try_hard_limit<F, R>(ms: usize, f: F) -> Result<R>
where
    F: Fn() -> Result<R>,
{
    let mut r;
    for i in 1..3 {
        r = f();
        if r.is_ok() {
            return r;
        } else if let Err(ref e) = r {
            error!("{}", e);
        };
        info!("retrying in {}ms", i * ms);
        thread::sleep(Duration::from_millis((i * ms) as u64));
    }

    f()
}


pub fn remove_dir_all(dir: &Path) -> Result<()> {
    try_hard_limit(10, || {
        fs::remove_dir_all(dir)?;
        if dir.exists() {
            bail!("unable to remove directory");
        } else {
            Ok(())
        }
    })
}

const MAX_REDIRECTS: usize = 4;

pub fn download(url: &str) -> Result<reqwest::Response> {
    try_hard(|| download_no_retry(url))
}

pub fn download_limit(url: &str, ms: usize) -> Result<reqwest::Response> {
    try_hard_limit(ms, || download_no_retry(url))
}

pub fn download_no_retry(url: &str) -> Result<reqwest::Response> {
    debug!{"Downloading {}", url};
    let client = reqwest::ClientBuilder::new()
        .redirect(reqwest::RedirectPolicy::limited(MAX_REDIRECTS))
        .build()
        .expect("could not setup https client");
    client.get(url).send().map_err(|e| e.into())
}