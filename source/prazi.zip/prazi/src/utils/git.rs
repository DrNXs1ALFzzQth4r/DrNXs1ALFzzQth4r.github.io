extern crate git2;
extern crate regex;

use self::git2::Repository;
use std::path::{Path, PathBuf};
use std::str;
use std::collections::HashMap;
use self::regex::Regex;


#[derive(Debug)]
pub struct CandidateRepo<'a> {
    pub owner: &'a str,
    pub name: &'a str,
}

fn is_empty_dir(p: &Path) -> bool {
    let count = p.read_dir().expect("works").count();
    count == 0
}

///
/// Should check whether its a valid git folder
///
pub fn clone_repo(repo: &CandidateRepo, path: &mut PathBuf) -> Result<Repository, git2::Error> {
    let url = format!("https://github.com/{}/{}", repo.owner, repo.name);
    path.push(repo.owner);
    path.push(repo.name);
    if !Path::new(path.as_path()).exists() {
        Repository::clone(&url, path)
    } else {
        if is_empty_dir(path.as_path()) {
            Repository::clone(&url, path)
        } else {
            Repository::open(path)
        }
    }
}

pub fn file_history(repo: &Repository, sort: git2::Sort, path: &str, oid: Option<git2::Oid>) -> Vec<(git2::Oid, String)>{
    let mut revwalk = repo.revwalk().expect("revwalk");
    revwalk.set_sorting(sort);
    if oid.is_none(){
        revwalk.push_head().expect("push head");
    } else {
        revwalk.push(oid.unwrap()).expect("push latest commit");
    }
    
    let mut map: HashMap<git2::Oid, String> = HashMap::new();
    let commits: Vec<git2::Oid> = revwalk.map(|x| x.unwrap()).collect();
    let mut result: Vec<(git2::Oid, String)> = Vec::new();

    for oid in commits {
        let current_path = if map.len() > 0 {
            map.get(&oid).unwrap().clone()
        } else {
            path.to_string()
        };
        let commit = repo.find_commit(oid).expect("commit");
        let tree = commit.tree().expect("tree");
        let tree_entry = tree.get_path(Path::new(&current_path));
        match tree_entry {
            Ok(entry) => {
                let parent_count = commit.parents().len();
               if parent_count == 0 {
                   result.push((commit.id(), current_path.clone()));
                } else {
                   determine_parents_paths(&repo, &commit, &current_path, &mut map);
                  if parent_count != 1 {
                      continue;
                  }
                  let parent_commit = commit.parent(0).expect("one parent");
                  let parent_path: &String = map.get(&parent_commit.id()).unwrap();
                  let parent_tree = parent_commit.tree().expect("tree");
                  match parent_tree.get_path(Path::new(parent_path)) {
                      Ok(parent_tree_entry) => {
                          if parent_tree_entry.id() != entry.id() ||
                              current_path != parent_path.to_string()
                         {
                             result.push((commit.id(), current_path.clone()));
                        };
                        }
                       Err(_) => result.push((commit.id(), current_path.clone())),
                    }
                }
            },
            Err(_) => break
        }
    }
    result
}


fn determine_parents_paths(
    repo: &Repository,
    commit: &git2::Commit,
    path: &str,
    map: &mut HashMap<git2::Oid, String>,
) {
    for parent in commit.parents() {
        if !map.contains_key(&parent.id()) {
            map.insert(parent.id(), parent_path(&repo, &commit, path, &parent));
        }
    }

}

fn parent_path(
    repo: &Repository,
    current_commit: &git2::Commit,
    current_path: &str,
    parent_commit: &git2::Commit,
) -> String {
    let current_tree = current_commit.tree().expect("tree");
    let parent_tree = parent_commit.tree().expect("tree");
    let mut tree_changes = repo.diff_tree_to_tree(Some(&parent_tree), Some(&current_tree), None)
        .unwrap();
    tree_changes.find_similar(None).unwrap();
    // tree_changes.foreach(& mut|c, i| {
    //     println!("Delta {}", i);
    //     println!("{:?}",c.new_file().path().unwrap());
    //     println!("{:?}",c.old_file().path().unwrap());
    //     println!("{:?}", c.status());
    //     true
    // },None, None, None).unwrap();

    let tree_change: Vec<git2::DiffDelta> = tree_changes
        .deltas()
        .take_while(|d| {
            let delta_path = d.new_file().path().unwrap().to_str().unwrap();
            delta_path == current_path
        })
        .collect();

    if tree_change.len() == 0 {
        String::from(current_path)
    } else {
        if tree_change[0].status() == git2::Delta::Renamed {
            let delta_path = tree_change[0].old_file().path().unwrap().to_str().unwrap();
            String::from(delta_path)
        } else {
            String::from(current_path)
        }

    }
}

pub fn find_files(repo: &Repository, pattern: &str) -> HashMap<String, git2::Oid>{
    let re = Regex::new(pattern).unwrap();
    let mut revwalk = repo.revwalk().expect("revwalk");
    revwalk.set_sorting(git2::SORT_TOPOLOGICAL);
    revwalk.push_head().expect("push head");
    let history: Vec<git2::Oid> = revwalk.map(|x| x.unwrap()).collect();
    let files: HashMap<String, git2::Oid> = history
        .windows(2)
        .map(|pair| {
            // old_id (most recent) -> new_id (2nd most recent)
            let (old_id, new_id) = (pair[0], pair[1]);
            let (old_commit, new_commit) = (
                repo.find_commit(old_id).expect("not found"),
                repo.find_commit(new_id).expect("not found"),
            );
            let (old_tree, new_tree) = (
                old_commit.tree().expect("not found"),
                new_commit.tree().expect("not found"),
            );
            let mut diff = repo.diff_tree_to_tree(Some(&old_tree), Some(&new_tree), None)
                .unwrap();
            diff.find_similar(None).unwrap();
            let paths: Vec<String> = diff.deltas()
                .map(|d| {
                    let delta_path = d.old_file().path().unwrap().to_str().unwrap();
                    // if d.status() == git2::Delta::Renamed && old_id == git2::Oid::from_str("0be9facfcfa13c2c3f1284207d4bc421f8f435fd").unwrap() {
                    //     println!("Renamed from {} to {}", &delta_path, &d.old_file().path().unwrap().to_str().unwrap());
                    //     println!("old_oid {} -> new_oid {}", old_id, new_id);
                    // }
                    String::from(delta_path)
                })
                .filter(|p| re.is_match(&p))
                .collect();
            (old_id, paths)
        })
        .filter(|pair| pair.1.len() > 0)
        .fold(HashMap::new(), |mut map, pair| {
            for path in pair.1 {
                if !map.contains_key(&path) {
                    map.insert(path, pair.0);
                }
            }
            map
        });
        files
}