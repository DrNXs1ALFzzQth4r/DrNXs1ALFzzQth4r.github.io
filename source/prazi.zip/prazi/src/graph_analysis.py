# graph_analysis.py
#
# (c) 2017 - onwards ANON
#
# MIT licensed -- check LICENSE file in top dir
import networkx as nx
import json
import sys
from pprint import pprint
import re

regex = r"^(.*?) \[label:"


def read_dep_graph(base_dir):
    nodes = json.load(open(base_dir + '/nodes.json'))
    edges = json.load(open(base_dir + '/edges.json'))

    DEPG = nx.DiGraph()

    for node in nodes['nodes']:
        DEPG.add_node(node)

    for edge in edges['versions']:
        DEPG.add_edge(edge[0]['id'], edge[1]['id'])

    return DEPG


def read_ucg(base_dir):
    UCG = nx.DiGraph()
    with open(base_dir + '/callgraph.ufi.merged.graph') as f:
        for line in f:
            if "->" not in line:
                g = re.match(regex, line)
                if g:
                    UCG.add_node(g.group(1).strip('"'))
                else:
                    print "error, could not extract node: %s" % line
            else:
                g = re.match('\W*"(.*)" -> "(.*)";', line)
                if g:
                    UCG.add_edge(g.group(1), g.group(2))
                else:
                    print "error, could not extract edge: %s" % line
    return UCG


def create_graph(seed_fn):
    dataset = []
    search_list = set()
    visited = []
    result = list(UCG.predecessors(seed_fn))
    for r in result:
        search_list.add(r)
        dataset.append((seed_fn, r))
    
    while search_list:
        print search_list
        search_value = search_list.pop()
        visited.append(search_value)

        result = list(UCG.predecessors(search_value))
        for r in result:
            if r not in visited:
                search_list.add(r)
            dataset.append((search_value, r))

    return dataset

def read_ucg_dep(base_dir):
    DEPCG = nx.DiGraph()
    with open(base_dir + '/crate.dependency.callgraph.graph') as f:
        for line in f:
            if "io :: crates :: " in line:
                if "->" not in line:
                    DEPCG.add_node(line[:-2])
                else:
                    g = re.match('\W*"(.*)" -> "(.*)";', line)
                    if g and ("io :: crates" in g.group(1) and "io :: crates" in g.group(2)):
                        DEPCG.add_edge(g.group(1), g.group(2))
                    else:
                        print "skip edge: %s" % line
            else:
                continue
    return DEPCG

def read_ucg_dep_from_file(file):
    DEPCG = nx.DiGraph()
    with open(file) as f:
        for line in f:
            if "io :: crates :: " in line:
                if "->" not in line:
                    DEPCG.add_node(line[:-2])
                else:
                    g = re.match('\W*"(.*)" -> "(.*)";', line)
                    if g and ("io :: crates" in g.group(1) and "io :: crates" in g.group(2)):
                        DEPCG.add_edge(g.group(1), g.group(2))
                    else:
                        print "skip edge: %s" % line
            else:
                continue
    return DEPCG


DEPG = read_dep_graph(sys.argv[1])
#UCG = read_ucg(sys.argv[2])
DEPCG = read_ucg_dep(sys.argv[2])

SUB_DEPG = nx.DiGraph()

# Copy nodes from DEPCG to CMP_DEPCG
for node in DEPCG.nodes():
    SUB_DEPG.add_node(node)

# We only want to have edges between "buildable" nodes
# "buildable" nodes are nodes that exist in DEPCG
for s, t in DEPG.edges():
    if DEPCG.has_node(s) and DEPCG.has_node(t):
        SUB_DEPG.add_edge(s, t)


# edges that are in SUB_DEPG but not in DEPCG
diff = nx.difference(SUB_DEPG, DEPCG)


# checking for generic
# >>> for s,t in DEPCG.edges():
# ...     if not DEPG.has_edge(s,t) and not DEPG.has_edge(t,s):
# ...             length, path = nx.bidirectional_dijkstra(DEPCG,s,t)
# ...             if length == 1:
# ...                     count_gen = count_gen + 1
# ...


# >>> for s,t in DEPCG.edges():
# ...     try:
# ...             print nx.bidirectional_dijkstra(CMP_DEPCG,s,t)
# ...     except:
# ...             print "no path between %s and %s" % (s,t)
# ...


# >>> for s,t in diff.edges():
# ...     if not nx.has_path(DEPCG,s,t):
# ...             print '"' + s + '"' + ',' + '"' + t + '"'
# ...

# edges = list(nx.bfs_edges(UCG,'io :: crates :: base64 :: v_0_4_2 :: base64 :: encode_config_buf',reverse=True))
# f = open("base64_edges.graph","w")
# for s,v in edges:
#     f.write('"' + s + '"' + ' -> ' + '"' + v + '"\n')
# f.close()
#
# B64 = read_ucg_dep_from_file('/data/advisories/base64_0.4.2_encode_config_buf')
# lvl1 = list(nx.bfs_edges(B64,'io :: crates :: base64 :: v_0_4_2', reverse=True))
