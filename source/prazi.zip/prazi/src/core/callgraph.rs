use ini::Ini;
use nix::unistd::pipe;
use std::process::{Command, Stdio, Child};
use std::process::Output;

use std;
use std::fs;
use std::os::unix::io::{FromRawFd, IntoRawFd};
use std::fs::File;
use std::path::{PathBuf,Path};
use std::error::Error;
use std::io::{ErrorKind};
use cargo::core::{Package};

const CONF_FILE_NAME: &'static str = "config.ini";


pub struct LLVMCallGraph {
    path: PathBuf,
}



pub type LLVMCallGraphResult = Result<LLVMCallGraph, std::io::Error>;
impl LLVMCallGraph {

    pub fn from_bitcode(bc_path: &str, target_dir: &str) -> LLVMCallGraphResult {
        info!("[LLVMCallGraph][from_bitcode] Init");
        info!("[LLVMCallGraph][from_bitcode] Building CallGraph for {} and stored at {}", bc_path, target_dir);
        match LLVMCallGraph::build_cg_2(bc_path, target_dir) {
            Ok(output) => {
                info!("[LLVMCallGraph][from_bitcode] Build LLVM OPT Chain - Status: {}", output.status);
                info!("[LLVMCallGraph][from_bitcode] Build LLVM OPT Chain - Stderr: {}", String::from_utf8_lossy(&output.stderr));
            },
            Err(e) => {
                info!("[LLVMCallGraph][from_bitcode] Build LLVM OPT Chain with error {}", e);
                return Err(e)
            }
        };

        let pruned_file = PathBuf::from(target_dir).join("pruned.dot");
        match LLVMCallGraph::prune_cg(target_dir, pruned_file.to_str().unwrap()) {
            Ok(output) => {
                info!("[LLVMCallGraph][from_bitcode] Build Prune Pipe Chain - Status: {}", output.status);
                info!("[LLVMCallGraph][from_bitcode] Build Prune Pipe Chain - Stdout: {}", String::from_utf8_lossy(&output.stdout));
                info!("[LLVMCallGraph][from_bitcode] Build Prune Pipe Chain - Stderr: {}", String::from_utf8_lossy(&output.stderr));

            },
            Err(e) => {
                info!("[LLVMCallGraph][from_bitcode] Build Prune Pipe Chain with error {}", e);
                return Err(e)
            }
        }
        Ok(LLVMCallGraph {path: pruned_file})
    }


    pub fn build_crate(crate_dir: &str) -> std::io::Result<Child> {
        let conf = Ini::load_from_file(CONF_FILE_NAME).unwrap();
        let cargo = conf.section(Some("cargo")).unwrap();
        Command::new(cargo.get("path").unwrap())
            .arg("rustc")
            .arg("--lib")
            .arg("--")
            .arg("--emit=llvm-bc")
            .current_dir(crate_dir)
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
    }

    pub fn build_callgraph(crate_dir: &str, bc_file: &str) -> std::io::Result<Child> {
        let conf = Ini::load_from_file(CONF_FILE_NAME).unwrap();
        let llvm = conf.section(Some("llvm")).unwrap();
        Command::new(format!("{}/bin/opt",llvm.get("path").unwrap()))
            .current_dir(crate_dir)
            .arg("-dot-callgraph")
            .arg(bc_file)
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
    }

    pub fn check_crate(crate_dir: &str) -> std::io::Result<Child> {
        let conf = Ini::load_from_file(CONF_FILE_NAME).unwrap();
        let cargo = conf.section(Some("cargo")).unwrap();
        Command::new(cargo.get("path").unwrap())
            .arg("check")
            .current_dir(crate_dir)
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
    }



    fn build_cg_2(bc_file: &str, target_dir: &str) -> std::io::Result<Output>{
        let conf = Ini::load_from_file(CONF_FILE_NAME).unwrap();
        let llvm = conf.section(Some("llvm")).unwrap();
        Command::new(format!("{}/bin/opt",llvm.get("path").unwrap()))
            .arg("-dot-callgraph")
            .arg(bc_file)
            .current_dir(target_dir)
            .output()
    }

    pub fn prune_cg(cg_dir: &str, target_file: &str) -> std::io::Result<Output> {
        let cat = match Command::new("cat")
            .arg("callgraph.dot")
            .current_dir(cg_dir)
            .stdout(Stdio::piped())
            .spawn(){
                Err(why) => panic!("couldn't spawn cat: {}", why.description()),
                Ok(process) => process,
        };
        let cat_out = cat.stdout.expect("Failed to open cat stdout");
        
        let rustfilt = match Command::new("rustfilt")
            .stdin(Stdio::from(cat_out))
            .stdout(Stdio::piped())
            .spawn(){
                Err(why) => panic!("couldn't spawn rustfile: {}", why.description()),
                Ok(process) => process,
            };        
        let rustfilt_out = rustfilt.stdout.expect("Failed to open cat stdout");

        let sed = match Command::new("sed")
            .arg("s,>,\\>,g; s,-\\>,->,g; s,<,\\<,g")
            .stdin(Stdio::from(rustfilt_out))
            .stdout(Stdio::piped())
            .spawn(){
                Err(why) => panic!("couldn't sed: {}", why.description()),
                Ok(process) => process,
        };
        let sed_out = sed.stdout.expect("Failed to open cat stdout");

        let fds = pipe().unwrap();
        let fd1 = File::create(target_file).unwrap().into_raw_fd();
          
        let (_, _, file_out) = unsafe {
            (Stdio::from_raw_fd(fds.0),
            Stdio::from_raw_fd(fds.1),
            Stdio::from_raw_fd(fd1))
        };

        let mut gawk = match Command::new("gawk")
            .arg("/external node/{id=$1} $1 != id")
            .stdin(Stdio::from(sed_out))
            .stdout(file_out)
            .spawn(){
                Err(why) => panic!("couldn't gawk: {}", why.description()),
                Ok(process) => process,
        }; 
        gawk.wait().unwrap();
        gawk.wait_with_output()
    }

    pub fn path(&self) -> &Path {
        self.path.as_path()
    }
}