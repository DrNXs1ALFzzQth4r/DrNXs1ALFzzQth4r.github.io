use errors::*;
use std::path::{Path, PathBuf};
use std::io::Read;
use std::fs;
use std::fs::File;
use std::io::{BufReader, Write};
use utils::dl;
use utils::crates_index;
use rayon::prelude::*;
use rayon::*;
use std::io::{BufWriter};
use std::fs::OpenOptions;
use glob::glob;

use cargo::util::Config;
use cargo::util::important_paths::find_project_manifest_exact;
use cargo::core::Package;
use toml;

use dirs::{LIST_DIR, CRATES_DIR};
use core::callgraph::LLVMCallGraph;

const CRATES_ROOT: &str = "https://crates-io.s3-us-west-1.amazonaws.com/crates";

pub trait List {
    fn create() -> Result<()>;
    fn read() -> Result<Vec<Crate>>;
    fn path() -> PathBuf;
}

#[derive(Debug, Eq, PartialEq, Ord, PartialOrd, Hash, Clone)]
pub struct Crate {
    name: String,
    version: String,
}

impl Crate {
    pub fn dir(&self) -> PathBuf {
        registry_dir().join(format!("{}/{}", self.name, self.version))
    }

    pub fn name(&self) -> &str {
        &self.name
    }
    pub fn version(&self) -> &str {
        &self.version
    }
}

fn registry_dir() -> PathBuf {
    CRATES_DIR.join("reg")
}

struct CratesList;

impl List for CratesList {
    fn create() -> Result<()> {
        info!("creating recent list");
        fs::create_dir_all(&*LIST_DIR)?;

        let crates = crates_index::crates_index_registry()?
            .crates()
            .flat_map(|crate_| {
                let mut names = Vec::with_capacity(crate_.versions().len());
                let mut versions = Vec::with_capacity(crate_.versions().len());
                for i in 0..crate_.versions().len() {
                    names.push(crate_.name().to_owned());
                    versions.push(crate_.versions()[i].version().to_owned())
                }
                names.into_iter().zip(versions)
            })
            .collect::<Vec<(String, String)>>();

        write_crate_list(&Self::path(), crates.into_iter())?;
        info!("recent crates written to {}", Self::path().display());
        Ok(())
    }

    fn read() -> Result<Vec<Crate>> {
        let lines = read_lines(&Self::path()).chain_err(
            || "unable to read recent list. run `crater create-lists`?",
        )?;
        split_crate_lines(&lines)
    }

    fn path() -> PathBuf {
        LIST_DIR.join("recent-crates.txt")
    }
}

// (String, String) corresponds to (crate name, crate version)
fn write_crate_list<I>(path: &Path, crates: I) -> Result<()>
where
    I: Iterator<Item = (String, String)>,
{
    let strings = crates
        .map(|(name, version)| format!("{}:{}", name, version))
        .collect::<Vec<_>>();
    write_lines(path, &strings)
}

fn split_crate_lines(lines: &[String]) -> Result<Vec<Crate>> {
    Ok(
        lines
            .iter()
            .filter_map(|line| {
                line.find(':').map(|i| {
                    (line[..i].to_string(), line[i + 1..].to_string())
                })
            })
            .map(|(name, version)| Crate { name, version })
            .collect(),
    )
}

pub fn read_lines(path: &Path) -> Result<Vec<String>> {
    let contents = read_string(path)?;
    Ok(
        contents
            .lines()
            .map(|l| l.to_string())
            .filter(|l| !l.chars().all(|c| c.is_whitespace()))
            .collect(),
    )
}

pub fn read_string(path: &Path) -> Result<String> {
    let mut f = BufReader::new(File::open(path)?);
    let mut buf = String::new();
    f.read_to_string(&mut buf)?;
    Ok(buf)
}

pub fn write_lines(path: &Path, lines: &[String]) -> Result<()> {
    write_string(path, &(lines.join("\n") + "\n"))
}

pub fn write_string(path: &Path, s: &str) -> Result<()> {
    let mut f = File::create(path)?;
    f.write_all(s.as_bytes())?;
    Ok(())
}

pub fn prepare() -> Result<()> {
    info!("Running with threads = {:?}", current_num_threads());
    //CratesList::create()?;
    let list = CratesList::read()?;
    let crates = &list.par_iter()
        .map(|crate_| crate_.name())
        .collect::<Vec<_>>();
    let mut crates_cloned = crates.clone();
    crates_cloned.dedup();

    info!("preparing {} crates", &crates_cloned.len());
    info!("preparing {} crate versions", &list.len());

    let download_succ = &list.par_iter()
        .map(|crate_| {
            let dir = crate_.dir();
            let mut successes = 0;
            let r = dl_registry(crate_.name(), crate_.version(), &dir)
                .chain_err(|| format!("unable to download {}-{}", crate_.name(), crate_.version()));
            if let Err(e) = r {
                report_error(&e);
            } else {
                successes = 1;
            }
            successes
        })
        .sum::<i32>();
    info!("{} of {} downloaded!", download_succ, &list.len());
    Ok(())
}


 pub fn readable_manifest() -> Result<()> {
    info!("Running with threads = {:?}", current_num_threads());
    let list = CratesList::read()?;
    
    let crate_libs = &list
        .par_iter()
        .map(|crate_| {
            let crate_dir = crate_.dir();
            let mut successes = 0;
            let path = find_project_manifest_exact(crate_dir.as_path(), "Cargo.toml").chain_err(|| format!("{}-{} could not find manifest ", crate_.name(), crate_.version()));
            if let Err(e) = path {
                report_error(&e);
            } else {
                let pkg_path_ok = path.unwrap();
                let pkg_res = Package::for_path(&pkg_path_ok, &Config::default().expect("Using Default config"));
                let manifest = pkg_res.chain_err(|| format!("{}-{} could not parse manifest ", crate_.name(), crate_.version()));
                if let Err(e) = manifest {
                    report_error(&e);
                } else {
                    successes = 1;
                }
            }
            successes
        }).sum::<i32>();

    info!("{} of {} have readable manifests!", crate_libs, &list.len());
    Ok(())
}

 pub fn readable_crates_manifest() -> Result<()> {
    info!("Running with threads = {:?}", current_num_threads());
    let list = CratesList::read()?;
    
    let crate_libs = &list
        .par_iter()
        .map(|crate_| {
            let crate_dir = crate_.dir();
            let mut successes = 0;
            let path = find_project_manifest_exact(crate_dir.as_path(), "Cargo.toml").chain_err(|| format!("{}-{} could not find manifest ", crate_.name(), crate_.version()));
            if let Err(e) = path {
                report_error(&e);
            } else {
                let pkg_path_ok = path.unwrap();
                let pkg_res = Package::for_path(&pkg_path_ok, &Config::default().expect("Using Default config"));
                let manifest = pkg_res.chain_err(|| format!("{}-{} could not parse manifest ", crate_.name(), crate_.version()));
                if let Err(e) = manifest {
                    report_error(&e);
                } else {
                    info!("VALID~~~{}", crate_.name());
                    successes = 1;
                }
            }
            successes
        }).sum::<i32>();

    info!("{} of {} have readable manifests!", crate_libs, &list.len());
    Ok(())
}


 pub fn normalize_manifests() -> Result<()> {
    info!("Running with threads = {:?}", current_num_threads());
    let list = CratesList::read()?;
    
    let crate_libs = &list
        .par_iter()
        .map(|crate_| {
            let crate_dir = crate_.dir();
            let mut successes = 0;
            let path = find_project_manifest_exact(crate_dir.as_path(), "Cargo.toml").chain_err(|| format!("({},{}): could not find manifest", crate_.name(), crate_.version()));
            if let Err(e) = path {
                report_error(&e);
            } else {
                let pkg_path_ok = path.unwrap();
                let pkg_res = Package::for_path(&pkg_path_ok, &Config::default().expect("Using Default config"));
                let mut new_path = pkg_path_ok.clone().parent().unwrap().to_path_buf();
                new_path.push("Cargo.toml.backup");
                info!("({},{}): rename from {} to {}", crate_.name(), crate_.version() ,pkg_path_ok.display(), new_path.display());
                fs::rename(&pkg_path_ok, new_path).expect(format!("({},{}): did not rename file", crate_.name(), crate_.version()).as_str());
                let manifest = pkg_res.chain_err(|| format!("({},{}): could not parse the manifest", crate_.name(), crate_.version()));
                if let Err(e) = manifest {
                    report_error(&e);
                } else {
                    let pkg = manifest.unwrap().clone();
                    let manifest = pkg.manifest().original().prepare_for_publish();
                    let toml = toml::to_string(&manifest).unwrap();
                    let proc_file = format!("\
                        # THIS FILE IS AUTOMATICALLY GENERATED BY CARGOGRAPH\n\
                        #\n\
                        # When uploading crates to the registry Cargo will automatically\n\
                        # \"normalize\" Cargo.toml files for maximal compatibility\n\
                        # with all versions of Cargo and also rewrite `path` dependencies\n\
                        # to registry (e.g. crates.io) dependencies\n\
                        #\n\
                        # If you believe there's an error in this file please file an\n\
                        # issue against the rust-lang/cargo repository. If you're\n\
                        # editing this file be aware that the upstream Cargo.toml\n\
                        # will likely look very different (and much more reasonable)\n\
                        \n\
                        {}\
                    ", toml);
                    let file = OpenOptions::new()
                        .read(true)
                        .write(true)
                        .create(true)
                        .open(&pkg_path_ok)
                        .expect(format!("({},{}): failed to create TOML file", crate_.name(), crate_.version()).as_str());
                    let mut writer = BufWriter::new(&file);
                    writer
                        .write_all(proc_file.as_bytes())
                        .expect(format!("({},{}): failed to write the file", crate_.name(), crate_.version()).as_str());
                    successes = 1;
                }
            }
            successes
        }).sum::<i32>();

    info!("{} of {} have readable manifests!", crate_libs, &list.len());
    Ok(())
}


 pub fn is_library_name() -> Result<()> {
    info!("Running with threads = {:?}", current_num_threads());
    let list = CratesList::read()?;
    
    let crate_libs = &list
        .par_iter()
        .map(|crate_| {
            let crate_dir = crate_.dir();
            let mut successes = 0;
            let path = find_project_manifest_exact(crate_dir.as_path(), "Cargo.toml").chain_err(|| format!("{}-{} could not find manifest ", crate_.name(), crate_.version()));
            if let Err(e) = path {
                report_error(&e);
            } else {
                let pkg_path_ok = path.unwrap();
                let pkg_res = Package::for_path(&pkg_path_ok, &Config::default().expect("Using Default config"));
                let manifest = pkg_res.chain_err(|| format!("{}-{} could not parse manifest ", crate_.name(), crate_.version()));
                if let Err(e) = manifest {
                    report_error(&e);
                } else {
                    let package = manifest.unwrap();
                    let lib_targets = package
                                        .targets()
                                        .into_iter()
                                        .filter(|target| target.is_lib() || target.is_dylib() || target.is_cdylib()) //maybe is_lib() covers all library targets
                                        .collect::<Vec<_>>();
                    if lib_targets.len() > 0 {
                        info!("LIBRARY:{}", crate_.name());
                        successes = 1;
                    } else {
                        info!("{}-{} is NOT a library", crate_.name(), crate_.version());
                    }
                }
            }
            successes
        }).sum::<i32>();

    info!("{} of {} have readable manifests!", crate_libs, &list.len());
    Ok(())
}




 pub fn islibrary() -> Result<()> {
    info!("Running with threads = {:?}", current_num_threads());
    let list = CratesList::read()?;
    
    let crate_libs = &list
        .par_iter()
        .map(|crate_| {
            let crate_dir = crate_.dir();
            let mut successes = 0;
            let path = find_project_manifest_exact(crate_dir.as_path(), "Cargo.toml").chain_err(|| format!("{}-{} could not find manifest ", crate_.name(), crate_.version()));
            if let Err(e) = path {
                report_error(&e);
            } else {
                let pkg_path_ok = path.unwrap();
                let pkg_res = Package::for_path(&pkg_path_ok, &Config::default().expect("Using Default config"));
                let manifest = pkg_res.chain_err(|| format!("{}-{} could not parse manifest ", crate_.name(), crate_.version()));
                if let Err(e) = manifest {
                    report_error(&e);
                } else {
                    let package = manifest.unwrap();
                    let lib_targets = package
                                        .targets()
                                        .into_iter()
                                        .filter(|target| target.is_lib() || target.is_dylib() || target.is_cdylib()) //maybe is_lib() covers all library targets
                                        .collect::<Vec<_>>();
                    if lib_targets.len() > 0 {
                        info!("{}-{} is a library with the following targets {:?}", crate_.name(), crate_.version(), lib_targets.iter().map(|t| t.kind()).collect::<Vec<_>>());
                        successes = 1;
                    } else {
                        info!("{}-{} is NOT a library", crate_.name(), crate_.version());
                    }
                }
            }
            successes
        }).sum::<i32>();

    info!("{} of {} have readable manifests!", crate_libs, &list.len());
    Ok(())
}

fn bitcode_exist(cargo_dir: &str) -> bool {
    let res = glob(format!("{}/target/debug/deps/*.bc", cargo_dir).as_str())
        .expect("Failed to read glob pattern")
        .map(|v| v.is_ok())
        .collect::<Vec<_>>();
    res.len() == 1
}

fn bitcode_path(cargo_dir: &str) -> PathBuf {
    let res = glob(format!("{}/target/debug/deps/*.bc", cargo_dir).as_str())
        .expect("Failed to read glob pattern")
        .filter(|v| v.is_ok())
        .map(|v| v.unwrap())
        .collect::<Vec<_>>();
    res[0].to_path_buf()
}


pub fn check_crate() -> Result<()> {
    let list = CratesList::read()?;
    info!("cheecking {} crates", &list.len());
    let successes = &list.par_iter()
        .map(|crate_| {
            let dir = crate_.dir();
            let mut successes = 0;
            if !bitcode_exist(&dir.to_str().unwrap()) && crate_.name() != "xss-probe" {
                let compile_proc = LLVMCallGraph::check_crate(&dir.to_str().unwrap()).expect(format!("({},{}): failed to execute the process", crate_.name(), crate_.version()).as_str());
                let proc_id = compile_proc.id();
                let output = compile_proc.wait_with_output().expect(format!("({},{}): failed to wait the process", crate_.name(), crate_.version()).as_str());
                if output.status.success() {
                    info!("({},{},{},stdout): {}", proc_id ,crate_.name(), crate_.version(), String::from_utf8_lossy(&output.stdout));
                    successes = 1;
                } else {
                    error!("({},{},{},stderr): {}", proc_id ,crate_.name(), crate_.version(), String::from_utf8_lossy(&output.stderr));
                }
            } else {
                info!("(none,{},{},stdout): skip check, bitcode exists", crate_.name(), crate_.version());
            }
        successes
    }).sum::<i32>();
    info!("{} of {} built!", successes, &list.len());
    Ok(())
}



pub fn build_crate() -> Result<()> {
    let list = CratesList::read()?;
    info!("building {} crates", &list.len());
    let successes = &list.par_iter()
        .map(|crate_| {
            let dir = crate_.dir();
            let mut successes = 0;
            if !bitcode_exist(&dir.to_str().unwrap()) && crate_.name() != "xss-probe" {
                let compile_proc = LLVMCallGraph::build_crate(&dir.to_str().unwrap()).expect(format!("({},{}): failed to execute the process", crate_.name(), crate_.version()).as_str());
                let proc_id = compile_proc.id();
                let output = compile_proc.wait_with_output().expect(format!("({},{}): failed to wait the process", crate_.name(), crate_.version()).as_str());
                if output.status.success() {
                    info!("({},{},{},stdout): {}", proc_id ,crate_.name(), crate_.version(), String::from_utf8_lossy(&output.stdout));
                    successes = 1;
                } else {
                    error!("({},{},{},stderr): {}", proc_id ,crate_.name(), crate_.version(), String::from_utf8_lossy(&output.stderr));
                }
            } else {
               info!("(none,{},{},stdout): crate already have a bitcode file", crate_.name(), crate_.version());
            }
        successes
    }).sum::<i32>();
    info!("{} of {} built!", successes, &list.len());
    Ok(())
}


pub fn build_callgraph() -> Result<()> {
    let list = CratesList::read()?;
    info!("attempting building {} callgraphs", &list.len());
    let successes = &list.par_iter()
        .map(|crate_| {
            let dir = crate_.dir();
            let mut successes = 0;
            if bitcode_exist(&dir.to_str().unwrap()) {
                let bc_file = bitcode_path(&dir.to_str().unwrap());
                let compile_proc = LLVMCallGraph::build_callgraph(&dir.to_str().unwrap(), bc_file.to_str().unwrap()).expect(format!("({},{}): failed to execute the process", crate_.name(), crate_.version()).as_str());
                let proc_id = compile_proc.id();
                let output = compile_proc.wait_with_output().expect(format!("({},{}): failed to wait the process", crate_.name(), crate_.version()).as_str());
                if output.status.success() {
                    info!("({},{},{},stdout): opt generated a callgraph", proc_id ,crate_.name(), crate_.version());
                    info!("({},{},{},stdout): existance: {}",proc_id ,crate_.name(), crate_.version(), Path::new(format!("{}/callgraph.dot", &dir.to_str().unwrap()).as_str()).exists());
                    successes = 1;
                } else {
                    error!("({},{},{},stderr): {}", proc_id ,crate_.name(), crate_.version(), String::from_utf8_lossy(&output.stderr));
                }
            } else {
                error!("(none,{},{},stdout): crate does not have a bitcode", crate_.name(), crate_.version());
            }
        successes
    }).sum::<i32>();
    info!("{} of {} constructed call graphs!", successes, &list.len());
    Ok(())
}

pub fn report_error(e: &Error) {
    error!("{}", e);

    for e in e.iter().skip(1) {
        error!("caused by: {}", e)
    }
}

fn dl_registry(name: &str, vers: &str, dir: &Path) -> Result<()> {
    if dir.exists() {
        info!(
            "crate {}-{} exists at {}. skipping",
            name,
            vers,
            dir.display()
        );
        return Ok(());
    }
    info!("downloading crate {}-{} to {}", name, vers, dir.display());
    let url = format!("{0}/{1}/{1}-{2}.crate", CRATES_ROOT, name, vers);
    let mut bin = dl::download(&url).chain_err(
        || format!("unable to download {}", url),
    )?;
    fs::create_dir_all(&dir)?;
    let filename = format!("{0}/please_untar.crate", dir.to_str().unwrap());
    let mut buf = Vec::new();
    bin.read_to_end(&mut buf).unwrap();
    let mut file = File::create(filename).unwrap();
    file.write_all(&buf).unwrap();
    Ok(())
}