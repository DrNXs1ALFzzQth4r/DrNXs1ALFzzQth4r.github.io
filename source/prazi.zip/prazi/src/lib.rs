#[macro_use(slog_o, slog_info, slog_log, slog_error, slog_record,
            slog_record_static, slog_b, slog_kv, slog_debug)]
extern crate slog;
#[macro_use] extern crate slog_scope;
extern crate slog_term;
#[macro_use] extern crate lazy_static;
extern crate ini;
extern crate nix;
extern crate cargo;
extern crate git2;
extern crate regex;
extern crate semver;
extern crate chrono;
extern crate reqwest;
extern crate tar;
extern crate flate2;
#[macro_use]
extern crate error_chain;
extern crate crates_index;
extern crate rayon;
extern crate glob;
extern crate syn;

extern crate toml;

pub mod utils;
pub mod core;
pub mod dirs;
#[macro_use]
pub mod log;
pub mod errors;

