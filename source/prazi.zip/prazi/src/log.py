# log.py -- Logging configuration
#
# (c) 2017 - onwards ANON
#
# MIT licensed -- check LICENSE file in top dir

import sys
import logging

logging.basicConfig(format='%(asctime)s [%(process)d]%(filename)s:%(lineno)d(%(funcName)s) --- %(message)s',
                    level=logging.DEBUG, stream=sys.stderr)

from logging import debug, error, info